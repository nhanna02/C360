package com.example.inventoryapp;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

/**
 * Wraps the runtime permission request for sending SMS notifications.
 * If the user denies permission, hasPermission() simply returns false from then on
 * and the rest of the app continues to function normally without this feature.
 */
public class SmsPermissionHelper {

    private static final String TAG = "SmsPermissionHelper";
    public static final int SMS_PERMISSION_REQUEST_CODE = 101;

    private final Activity activity;
    private boolean permissionGranted;

    public SmsPermissionHelper(Activity activity) {
        this.activity = activity;
        this.permissionGranted = ContextCompat.checkSelfPermission(activity,
                Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    public boolean hasPermission() {
        return permissionGranted;
    }

    /** Prompts the user for SEND_SMS permission if it has not already been granted. */
    public void requestPermissionIfNeeded() {
        if (!permissionGranted) {
            ActivityCompat.requestPermissions(activity,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_REQUEST_CODE);
        }
    }

    /** Call this from the Activity's onRequestPermissionsResult. */
    public void handlePermissionResult(int requestCode, int[] grantResults) {
        if (requestCode == SMS_PERMISSION_REQUEST_CODE) {
            permissionGranted = grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (permissionGranted) {
                Toast.makeText(activity, "SMS alerts enabled.", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(activity,
                        "SMS alerts disabled. The app will keep working without them.",
                        Toast.LENGTH_SHORT).show();
            }
        }
    }

    /**
     * Sends a low-stock SMS alert to the given phone number, but only if permission
     * was granted. If permission was denied, this safely does nothing.
     */
    public void sendLowStockAlert(String phoneNumber, String itemName, int quantity) {
        if (!permissionGranted) {
            // No permission: app continues without this feature, no crash, no alert.
            return;
        }
        try {
            String message = activity.getString(R.string.low_stock_alert, itemName, quantity);
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);
        } catch (Exception e) {
            // The emulator may not support real SMS sending; fail quietly rather than crash.
            Log.e(TAG, "Failed to send SMS alert", e);
        }
    }
}

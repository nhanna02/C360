package com.example.inventoryapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Lets a first-time user create a new login and password.
 * The new account is saved to the users table so it persists across app sessions.
 */
public class RegisterActivity extends AppCompatActivity {

    private EditText newUsernameInput;
    private EditText newPasswordInput;
    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        databaseHelper = new DatabaseHelper(this);

        newUsernameInput = findViewById(R.id.newUsernameInput);
        newPasswordInput = findViewById(R.id.newPasswordInput);
        Button registerSubmitButton = findViewById(R.id.registerSubmitButton);

        registerSubmitButton.setOnClickListener(v -> attemptRegister());
    }

    private void attemptRegister() {
        String username = newUsernameInput.getText().toString().trim();
        String password = newPasswordInput.getText().toString().trim();

        if (TextUtils.isEmpty(username) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, R.string.register_error_empty, Toast.LENGTH_SHORT).show();
            return;
        }

        boolean success = databaseHelper.registerUser(username, password);
        if (success) {
            Toast.makeText(this, "Account created. You can now log in.", Toast.LENGTH_SHORT).show();
            finish();
        } else {
            Toast.makeText(this, R.string.register_error_exists, Toast.LENGTH_SHORT).show();
        }
    }
}

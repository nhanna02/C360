package com.example.inventoryapp;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

/**
 * Used both to add a brand-new inventory item and to edit an existing one.
 * If an ITEM_ID is passed in via the Intent, this screen behaves as an editor;
 * otherwise it creates a new item.
 */
public class AddEditItemActivity extends AppCompatActivity {

    private EditText itemNameInput;
    private EditText itemQuantityInput;
    private DatabaseHelper databaseHelper;
    private String username;
    private long itemId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_edit_item);

        databaseHelper = new DatabaseHelper(this);
        username = getIntent().getStringExtra("USERNAME");

        itemNameInput = findViewById(R.id.itemNameInputField);
        itemQuantityInput = findViewById(R.id.itemQuantityInputField);
        Button saveButton = findViewById(R.id.saveItemButton);

        if (getIntent().hasExtra("ITEM_ID")) {
            itemId = getIntent().getLongExtra("ITEM_ID", -1);
            itemNameInput.setText(getIntent().getStringExtra("ITEM_NAME"));
            itemQuantityInput.setText(String.valueOf(getIntent().getIntExtra("ITEM_QUANTITY", 0)));
        }

        saveButton.setOnClickListener(v -> saveItem());
    }

    private void saveItem() {
        String name = itemNameInput.getText().toString().trim();
        String quantityStr = itemQuantityInput.getText().toString().trim();

        if (TextUtils.isEmpty(name) || TextUtils.isEmpty(quantityStr)) {
            Toast.makeText(this, "Please enter both a name and a quantity.", Toast.LENGTH_SHORT).show();
            return;
        }

        int quantity;
        try {
            quantity = Integer.parseInt(quantityStr);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Quantity must be a number.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (itemId == -1) {
            databaseHelper.addItem(name, quantity, username);
        } else {
            databaseHelper.updateItem(itemId, name, quantity);
        }
        finish();
    }
}

package com.example.inventoryapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.GridView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AlertDialog;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.List;

/**
 * Main screen shown after a successful login. Displays the user's inventory in a
 * grid and lets them add, edit, or delete items. Also requests SMS permission so
 * the app can send low-stock alerts; if the user denies it, everything else here
 * still works normally.
 */
public class MainActivity extends AppCompatActivity {

    public static final String PLACEHOLDER_PHONE_NUMBER = "5555551234";

    private DatabaseHelper databaseHelper;
    private GridView inventoryGrid;
    private InventoryAdapter adapter;
    private String currentUsername;
    private SmsPermissionHelper smsPermissionHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        currentUsername = getIntent().getStringExtra("USERNAME");
        databaseHelper = new DatabaseHelper(this);
        smsPermissionHelper = new SmsPermissionHelper(this);

        inventoryGrid = findViewById(R.id.inventoryGrid);
        FloatingActionButton addItemButton = findViewById(R.id.addItemButton);

        addItemButton.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, AddEditItemActivity.class);
            intent.putExtra("USERNAME", currentUsername);
            startActivity(intent);
        });

        // Ask the user for permission to send SMS notifications. The rest of the
        // app's functionality does not depend on the result of this request.
        smsPermissionHelper.requestPermissionIfNeeded();

        inventoryGrid.setOnItemClickListener((parent, view, position, id) ->
                showEditDeleteDialog(adapter.getItem(position)));
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshGrid();
    }

    private void refreshGrid() {
        List<InventoryItem> items = databaseHelper.getAllItems(currentUsername);
        adapter = new InventoryAdapter(this, items);
        inventoryGrid.setAdapter(adapter);
        checkForLowStock(items);
    }

    /** Sends an SMS alert for any item at or below the low-stock threshold. */
    private void checkForLowStock(List<InventoryItem> items) {
        if (!smsPermissionHelper.hasPermission()) {
            // Permission was denied; skip notifications, app continues normally.
            return;
        }
        for (InventoryItem item : items) {
            if (item.getQuantity() <= DatabaseHelper.getLowStockThreshold()) {
                smsPermissionHelper.sendLowStockAlert(PLACEHOLDER_PHONE_NUMBER,
                        item.getName(), item.getQuantity());
            }
        }
    }

    private void showEditDeleteDialog(InventoryItem item) {
        new AlertDialog.Builder(this)
                .setTitle(item.getName())
                .setMessage("Quantity: " + item.getQuantity())
                .setPositiveButton("Edit", (dialog, which) -> {
                    Intent intent = new Intent(MainActivity.this, AddEditItemActivity.class);
                    intent.putExtra("USERNAME", currentUsername);
                    intent.putExtra("ITEM_ID", item.getId());
                    intent.putExtra("ITEM_NAME", item.getName());
                    intent.putExtra("ITEM_QUANTITY", item.getQuantity());
                    startActivity(intent);
                })
                .setNegativeButton("Delete", (dialog, which) -> {
                    databaseHelper.deleteItem(item.getId());
                    refreshGrid();
                })
                .setNeutralButton("Cancel", null)
                .show();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        smsPermissionHelper.handlePermissionResult(requestCode, grantResults);
    }
}

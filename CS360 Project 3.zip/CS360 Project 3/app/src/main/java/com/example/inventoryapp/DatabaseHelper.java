package com.example.inventoryapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * DatabaseHelper manages the persistent SQLite database for the app.
 * It holds two tables:
 *   - users: stores login credentials so accounts persist between sessions
 *   - inventory: stores the inventory items shown in the grid (Create/Read/Update/Delete)
 */
public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "inventory_app.db";
    private static final int DATABASE_VERSION = 1;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "_id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "_id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_ITEM_QUANTITY = "quantity";
    public static final String COL_OWNER_USERNAME = "owner_username";

    private static final int LOW_STOCK_THRESHOLD = 3;

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE NOT NULL, "
                + COL_PASSWORD + " TEXT NOT NULL);";

        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT NOT NULL, "
                + COL_ITEM_QUANTITY + " INTEGER NOT NULL, "
                + COL_OWNER_USERNAME + " TEXT NOT NULL);";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // ---------- User account methods ----------

    /** Returns true if the username/password combo matches a stored account. */
    public boolean checkUserCredentials(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, password},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /** Returns true if the username is already taken. */
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_USERS,
                new String[]{COL_USER_ID},
                COL_USERNAME + "=?",
                new String[]{username},
                null, null, null);
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    /** Creates a new login and password, saving it to the users table. Returns true on success. */
    public boolean registerUser(String username, String password) {
        if (userExists(username)) {
            return false;
        }
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, password);
        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    // ---------- Inventory CRUD methods ----------

    /** Create: adds a new inventory item owned by the given user. */
    public long addItem(String itemName, int quantity, String owner) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QUANTITY, quantity);
        values.put(COL_OWNER_USERNAME, owner);
        return db.insert(TABLE_INVENTORY, null, values);
    }

    /** Read: returns all inventory items belonging to the given user, for display in the grid. */
    public List<InventoryItem> getAllItems(String owner) {
        List<InventoryItem> items = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_INVENTORY,
                null,
                COL_OWNER_USERNAME + "=?",
                new String[]{owner},
                null, null, COL_ITEM_NAME + " ASC");

        if (cursor.moveToFirst()) {
            do {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(COL_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(COL_ITEM_QUANTITY));
                items.add(new InventoryItem(id, name, qty));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return items;
    }

    /** Update: changes the quantity (or name) associated with an existing item. */
    public boolean updateItem(long id, String itemName, int quantity) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_ITEM_NAME, itemName);
        values.put(COL_ITEM_QUANTITY, quantity);
        int rows = db.update(TABLE_INVENTORY, values, COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    /** Delete: removes an item from the inventory. */
    public boolean deleteItem(long id) {
        SQLiteDatabase db = this.getWritableDatabase();
        int rows = db.delete(TABLE_INVENTORY, COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)});
        return rows > 0;
    }

    public static int getLowStockThreshold() {
        return LOW_STOCK_THRESHOLD;
    }
}

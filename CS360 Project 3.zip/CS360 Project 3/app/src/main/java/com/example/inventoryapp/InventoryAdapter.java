package com.example.inventoryapp;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import java.util.List;

/**
 * Adapter that displays the list of InventoryItem objects in a grid.
 * Each cell shows the item name and current quantity, and items at or below the
 * low-stock threshold are highlighted in red.
 */
public class InventoryAdapter extends BaseAdapter {

    private final Context context;
    private final List<InventoryItem> items;

    public InventoryAdapter(Context context, List<InventoryItem> items) {
        this.context = context;
        this.items = items;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public InventoryItem getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).getId();
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            view = LayoutInflater.from(context).inflate(R.layout.item_inventory, parent, false);
        }

        InventoryItem item = items.get(position);

        TextView nameText = view.findViewById(R.id.itemNameText);
        TextView quantityText = view.findViewById(R.id.itemQuantityText);

        nameText.setText(item.getName());
        quantityText.setText(String.valueOf(item.getQuantity()));

        if (item.getQuantity() <= DatabaseHelper.getLowStockThreshold()) {
            quantityText.setTextColor(ContextCompat.getColor(context, R.color.colorLowStock));
        } else {
            quantityText.setTextColor(Color.BLACK);
        }

        return view;
    }
}
